//============================================================================
// Name        : BinarySearchTree.cpp
// Author      : Charlotte Mancini
// Version     : 1.0
// Copyright   : Copyright � 2017 SNHU COCE
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "CSVparser.hpp"
#include <ctype.h>

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================


// define a structure to hold course information
struct Course {
    string courseNumber; // unique identifier
    string title;
    string pre1;
    string pre2;
    Course() {

    }
};

// Internal structure for tree node
struct Node {
    Course course;
    Node* left;
    Node* right;

    // default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }

    // initialize with a course
    Node(Course aCourse) :
        Node() {
        this->course = aCourse;
    }
};

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class BinarySearchTree {

private:
    Node* root;
    void addNode(Node* node, Course course);
    void inOrder(Node* node);

public:

    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    void Insert(Course course);
    Course Search(string courseKey);
};

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
    // initialize housekeeping variables

    //root is equal to nullptr
    root = nullptr;
}

/**
 * Destructor
 */
BinarySearchTree::~BinarySearchTree() {

}

/**
 * Traverse the tree in order
 */
void BinarySearchTree::InOrder() {

    // call inOrder function and pass root 
    inOrder(root);
}

/**
 * Insert a course
 */
void BinarySearchTree::Insert(Course course) {

    // Insert a course into the tree

    // if root equal to null ptr
    if (root == nullptr) {

        // root is equal to new node course
        root = new Node(course);
    }

    // else
    else {

        // add Node root and course
        this->addNode(root, course);
    }
}

/**
 * Search for an individual course and its prerequisites, if any
 */
Course BinarySearchTree::Search(string courseKey) {
    // Search the tree for a specific course

    // set current node equal to root
    Node* current = root;

    // keep looping downwards until bottom reached or matching courseNumber found
    while (current != nullptr) {

        // if match found, return current course
        if (current->course.courseNumber.compare(courseKey) == 0) {
            return current->course;
        }

        // if course is smaller than current node then traverse left
        if (courseKey.compare(current->course.courseNumber) < 0) {
            current = current->left;
        }
        // else larger so traverse right
        else {
            current = current->right;
        }
    }
    Course course;
    return course;
}

/**
 * Add a course to some node (recursive)
 *
 * @param node Current node in tree
 * @param Course Course to be added
 */
void BinarySearchTree::addNode(Node* node, Course course) {

    // Insert a course into the tree

    // if node is larger then add to left
    if (node->course.courseNumber.compare(course.courseNumber) > 0) {

        // if no left node
        if (node->left == nullptr) {

            // this node becomes left
            node->left = new Node(course);
        }

        // else recurse down the left node
        else {
            this->addNode(node->left, course);
        }
    }

    //else
    else {
        // if no right node
        if (node->right == nullptr) {

            // this node becomes right
            node->right = new Node(course);
        }

        //else
        else {

            // recurse down the right node
            this->addNode(node->right, course);
        }
    }
}

void BinarySearchTree::inOrder(Node* node) {

    //if node is not equal to null ptr
    if (node != nullptr) {

        //inOrder not left
        inOrder(node->left);

        //output courseNumber, title, amount, fund
        cout << node->course.courseNumber << ": " << node->course.title << endl;

        //inOrder right
        inOrder(node->right);
    }
}


//============================================================================
// Static methods used for testing
//============================================================================

/**
 * * Display course information
 */
void displayCourse(Course course) {

    // if no prerequisites  
    if (course.pre1.empty()) {
        cout << "Course Number: " << course.courseNumber << ", " << course.title << endl << endl;

    }
    else {

        // if only 1 prerequisite
        if (course.pre2.empty()) {
            cout << "Course Number: " << course.courseNumber << ", " << course.title
                << endl;
            cout << "Prequisite: " << course.pre1 << endl << endl;
        }

        else {
            // if 2 prerequisites
            cout << "Course Number: " << course.courseNumber << ", " << course.title << endl;
            cout << "Prerequisites: " << course.pre1 << ", " << course.pre2
                << endl << endl;
        }

    }
    return;
}

/**
 * Load a CSV file containing courses into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the courses read
 */
void loadCourses(string csvPath, BinarySearchTree* bst) {
    cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add the collection of courses
            Course course;
            course.courseNumber = file[i][0];
            course.title = file[i][1];
            course.pre1 = file[i][2];
            course.pre2 = file[i][3];

            //cout << course.courseNumber << ":" << course.title << ", " << course.pre1 << "," << course.pre2 << endl;

            // push this course to the end
            bst->Insert(course);
        }
    }
    catch (csv::Error& e) {
        std::cerr << e.what() << std::endl;
    }

    cout << "File loaded." << endl;
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath, courseKey;
    csvPath = "ABC_course_list.csv";

    // Define a binary search tree to hold all courses
    BinarySearchTree* bst;
    bst = new BinarySearchTree();

    Course course;
    int choice = 0;

    while (choice != 4) {

        // Display menu
        cout << endl;
        cout << " ABC University Course Menu:" << endl << endl;
        cout << "  1. Load Courses" << endl;
        cout << "  2. Display All Courses" << endl;
        cout << "  3. Find Individual Course Info" << endl;
        cout << "  4. Exit" << endl << endl;

        cout << "Enter choice: ";
        cin >> choice;
        cout << endl;

        // Validate menu selection
        if (choice > 4 || choice < 0) {
            cout << " Choice is not valid. Please try again." << endl << endl;
        }

        if (choice == 0) {
            cout << " Choice must be a number (1-4). Try again next time!" << endl;
            break;
        }

        // Implement menu
        switch (choice) {

        case 1:

            // load the courses from file

            loadCourses(csvPath, bst);

            break;

        case 2:

            // sort courses and display list

            cout << "\nABC University Course List: " << endl << endl;
            bst->InOrder();

            break;

        case 3:

            // search for specific course and display course info

            cout << "Please enter the course number: " << endl;
            cin >> courseKey;

            // enable lower case entries by converting to upper case
            for (auto& c : courseKey)c = toupper(c);

            cout << endl;

            course = bst->Search(courseKey);

            if (!course.courseNumber.empty()) {
                displayCourse(course);
            }
            else {
                cout << "Course Number " << courseKey << " not found." << endl;
            }

            break;

        case 4:

            // exit the program

            cout << "Good bye." << endl;
            break;

        }
    }

    return 0;
}




